package net.customcrossbowsounds.client.hud;

import me.shedaniel.autoconfig.AutoConfig;
import net.customcrossbowsounds.config.CustomCrossbowSoundsConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.math.RotationAxis;

public class ArrowHudEditScreen extends Screen {

    private final Screen parent;
    private final CustomCrossbowSoundsConfig config;

    // Drag state
    private boolean draggingArrow = false;
    private boolean draggingCharge = false;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;

    public ArrowHudEditScreen(Screen parent) {
        super(Text.literal("Edit HUD Positions"));
        this.parent = parent;
        this.config = AutoConfig.getConfigHolder(CustomCrossbowSoundsConfig.class).getConfig();
    }

    @Override
    protected void init() {
        super.init();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        // Top instruction texts
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§aSürükle §7→ konumu ayarla  §aScroll §7→ boyut  §aESC §7→ kapat"),
                this.width / 2, 24, 0xAAAAAA);

        if (config.arrowHudEnabled) {
            renderArrowMock(context, mouseX, mouseY);
        }
        if (config.chargeIndicatorEnabled) {
            renderChargeMock(context, mouseX, mouseY);
        }

        // Show current coordinates while dragging tracking
        if (draggingArrow) {
            String coords = "§7Ok X: §f" + config.arrowHudX + " §7Y: §f" + config.arrowHudY;
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(coords), this.width / 2,
                    this.height - 20, 0xFFFFFF);
        } else if (draggingCharge) {
            String coords = "§7Şarj X: §f" + config.chargeIndicatorX + " §7Y: §f" + config.chargeIndicatorY;
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(coords), this.width / 2,
                    this.height - 20, 0xFFFFFF);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    private void renderArrowMock(DrawContext context, int mouseX, int mouseY) {
        int hudX = config.arrowHudX;
        int hudY = config.arrowHudY;
        float scale = config.arrowHudScale;

        // Bounding box for side-by-side view (approx. 56x16)
        int boxW = (int) (56 * scale);
        int boxH = (int) (18 * scale);

        boolean hovering = isHoveringArrow(mouseX, mouseY);

        if (hovering || draggingArrow) {
            context.fill(hudX - 3, hudY - 3, hudX + boxW + 3, hudY + boxH + 3, 0xAAFF8800);
            context.fill(hudX - 1, hudY - 1, hudX + boxW + 1, hudY + boxH + 1, 0x00000000);
        } else {
            // Sadece hover yapılabilir alanı belli eden şeffaf border
            context.fill(hudX - 2, hudY - 2, hudX + boxW + 2, hudY + boxH + 2, 0x55FFFFFF);
        }

        context.getMatrices().pushMatrix();
        context.getMatrices().translate((float) hudX, (float) hudY);
        context.getMatrices().scale(scale, scale);

        // Yan yana Düzen (Kalan / Yüklü)
        context.drawItem(new ItemStack(Items.ARROW), 0, 0); // Mock Remaining Arrow
        String countStr = "64";
        context.drawTextWithShadow(this.textRenderer, countStr, 18, 4, 0xFFFFFF);

        int currentX = 18 + this.textRenderer.getWidth(countStr) + 4;
        context.drawTextWithShadow(this.textRenderer, "§7/", currentX, 4, 0xFFFFFF);
        currentX += 10;
        context.drawItem(new ItemStack(Items.SPECTRAL_ARROW), currentX, 0); // Mock Loaded Arrow

        context.getMatrices().popMatrix();
    }

    private void renderChargeMock(DrawContext context, int mouseX, int mouseY) {
        int centerX = (this.width / 2) + config.chargeIndicatorX;
        int centerY = (this.height / 2) + config.chargeIndicatorY;
        float scale = config.chargeIndicatorScale;

        int radius = (int) (8 * scale);
        boolean hovering = isHoveringCharge(mouseX, mouseY);

        if (hovering || draggingCharge) {
            context.fill(centerX - radius - 3, centerY - radius - 3, centerX + radius + 3, centerY + radius + 3,
                    0xAAFF8800);
            context.fill(centerX - radius - 1, centerY - radius - 1, centerX + radius + 1, centerY + radius + 1,
                    0x00000000);
        } else {
            context.fill(centerX - radius - 2, centerY - radius - 2, centerX + radius + 2, centerY + radius + 2,
                    0x55FFFFFF);
        }

        context.getMatrices().pushMatrix();
        context.getMatrices().translate((float) centerX, (float) centerY);
        context.getMatrices().scale(scale, scale);

        // draw half full
        drawMockArc(context, 6, 0.75f, config.chargeIndicatorType, 0xAAFFFFFF);

        context.getMatrices().popMatrix();
    }

    private void drawMockArc(DrawContext context, float radius, float progress,
            CustomCrossbowSoundsConfig.ChargeIndicatorType type, int argb) {

        int gridR = 4; // 9x9 tam kare alan
        float outerRadiusSq = 4.5f * 4.5f;
        float innerRadiusSq = 2.0f * 2.0f; // Simit kalınlığı

        for (int y = -gridR; y <= gridR; y++) {
            for (int x = -gridR; x <= gridR; x++) {
                float cx = x + 0.5f;
                float cy = y + 0.5f;
                float distSq = cx * cx + cy * cy;

                if (distSq <= outerRadiusSq) {
                    if (type == CustomCrossbowSoundsConfig.ChargeIndicatorType.DONUT && distSq < innerRadiusSq) {
                        continue;
                    }

                    double angle = Math.toDegrees(Math.atan2(cy, cx)) + 90.0;
                    if (angle < 0)
                        angle += 360.0;

                    if (angle / 360.0 <= progress) {
                        context.fill(x, y, x + 1, y + 1, argb);
                    }
                }
            }
        }
    }

    private boolean isHoveringArrow(double mouseX, double mouseY) {
        float scale = config.arrowHudScale;
        int startX = config.arrowHudX;
        int startY = config.arrowHudY;
        int endX = startX + (int) (56 * scale);
        int endY = startY + (int) (18 * scale);
        return mouseX >= startX && mouseX <= endX && mouseY >= startY && mouseY <= endY;
    }

    private boolean isHoveringCharge(double mouseX, double mouseY) {
        float scale = config.chargeIndicatorScale;
        int centerX = (this.width / 2) + config.chargeIndicatorX;
        int centerY = (this.height / 2) + config.chargeIndicatorY;
        int radius = (int) (8 * scale);
        return mouseX >= centerX - radius && mouseX <= centerX + radius
                && mouseY >= centerY - radius && mouseY <= centerY + radius;
    }

    @Override
    public boolean mouseClicked(Click click, boolean bl) {
        if (click.button() == 0) {
            if (config.arrowHudEnabled && isHoveringArrow(click.x(), click.y())) {
                draggingArrow = true;
                dragOffsetX = (int) click.x() - config.arrowHudX;
                dragOffsetY = (int) click.y() - config.arrowHudY;
                return true;
            } else if (config.chargeIndicatorEnabled && isHoveringCharge(click.x(), click.y())) {
                draggingCharge = true;
                int centerX = (this.width / 2) + config.chargeIndicatorX;
                int centerY = (this.height / 2) + config.chargeIndicatorY;
                dragOffsetX = (int) click.x() - centerX;
                dragOffsetY = (int) click.y() - centerY;
                return true;
            }
        }
        return super.mouseClicked(click, bl);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (click.button() == 0) {
            if (draggingArrow || draggingCharge) {
                saveConfig();
            }
            draggingArrow = false;
            draggingCharge = false;
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public void mouseMoved(double mouseX, double mouseY) {
        if (draggingArrow) {
            config.arrowHudX = (int) mouseX - dragOffsetX;
            config.arrowHudY = (int) mouseY - dragOffsetY;
            config.arrowHudX = Math.max(0, Math.min(this.width - 40, config.arrowHudX));
            config.arrowHudY = Math.max(0, Math.min(this.height - 40, config.arrowHudY));
        } else if (draggingCharge) {
            int newCenterX = (int) mouseX - dragOffsetX;
            int newCenterY = (int) mouseY - dragOffsetY;
            config.chargeIndicatorX = newCenterX - (this.width / 2);
            config.chargeIndicatorY = newCenterY - (this.height / 2);
        }
        super.mouseMoved(mouseX, mouseY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount != 0) {
            if (isHoveringArrow(mouseX, mouseY)) {
                float newScale = config.arrowHudScale + (float) (verticalAmount * 0.1);
                if (newScale >= 0.5f && newScale <= 5.0f) {
                    config.arrowHudScale = newScale;
                    saveConfig();
                }
                return true;
            } else if (isHoveringCharge(mouseX, mouseY)) {
                float newScale = config.chargeIndicatorScale + (float) (verticalAmount * 0.1);
                if (newScale >= 0.5f && newScale <= 5.0f) {
                    config.chargeIndicatorScale = newScale;
                    saveConfig();
                }
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    private void saveConfig() {
        AutoConfig.getConfigHolder(CustomCrossbowSoundsConfig.class).save();
    }

    @Override
    public void close() {
        saveConfig();
        if (MinecraftClient.getInstance() != null) {
            MinecraftClient.getInstance().setScreen(this.parent);
        }
    }
}
