package net.customcrossbowsounds.client.hud;

import me.shedaniel.autoconfig.AutoConfig;
import net.customcrossbowsounds.config.CustomCrossbowSoundsConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.item.*;
import net.minecraft.registry.tag.ItemTags;

public class ArrowHudRenderer implements HudRenderCallback {

    // --- Bounce animation state ---
    private int lastCount = -1;
    private float bounceScale = 1.0f; // 1.0 = normal, >1 = zoomed in
    private float bounceVelocity = 0.0f;
    private long lastTickTime = 0;

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        CustomCrossbowSoundsConfig config = AutoConfig.getConfigHolder(CustomCrossbowSoundsConfig.class).getConfig();

        if (!config.arrowHudEnabled || !config.enabled)
            return;

        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null)
            return;

        ItemStack mainHandItem = player.getMainHandStack();
        ItemStack offHandItem = player.getOffHandStack();

        boolean hasBow = mainHandItem.getItem() instanceof BowItem || offHandItem.getItem() instanceof BowItem;
        boolean hasCrossbow = mainHandItem.getItem() instanceof CrossbowItem
                || offHandItem.getItem() instanceof CrossbowItem;

        if (!hasBow && !hasCrossbow)
            return;

        ItemStack arrowStack = getRelevantArrow(player, mainHandItem, offHandItem, hasCrossbow);
        if (arrowStack == null || arrowStack.isEmpty())
            return;

        int totalArrows = countArrowsOfType(player, arrowStack);

        // --- Trigger bounce when count changes ---
        if (totalArrows != lastCount && lastCount != -1) {
            bounceVelocity = 0.70f; // kick upward (Kullanıcı isteği: zıplama artırıldı)
        }
        lastCount = totalArrows;

        // --- Update bounce spring (simple spring physics) ---
        long now = System.currentTimeMillis();
        float dt = Math.min((now - lastTickTime) / 50.0f, 3.0f); // capped delta
        lastTickTime = now;

        float springK = 12.0f;
        float damping = 6.0f;
        float target = 1.0f;
        float force = -springK * (bounceScale - target) - damping * bounceVelocity;
        bounceVelocity += force * dt * 0.016f;
        bounceScale += bounceVelocity * dt * 0.016f;
        bounceScale = Math.max(0.8f, Math.min(2.0f, bounceScale));

        // --- Loaded arrow ---
        ItemStack loadedArrow = ItemStack.EMPTY;
        if (hasCrossbow) {
            ItemStack crossbow = mainHandItem.getItem() instanceof CrossbowItem ? mainHandItem : offHandItem;
            ChargedProjectilesComponent charged = crossbow.get(DataComponentTypes.CHARGED_PROJECTILES);
            if (charged != null && !charged.isEmpty()) {
                loadedArrow = charged.getProjectiles().get(0);
            }
        }

        renderArrowHud(context, config, arrowStack, totalArrows, loadedArrow, client);
    }

    private void renderArrowHud(DrawContext context, CustomCrossbowSoundsConfig config,
            ItemStack arrowStack, int count,
            ItemStack loadedArrow, MinecraftClient client) {
        int x = config.arrowHudX;
        int y = config.arrowHudY;
        float baseScale = config.arrowHudScale;
        float opacity = config.arrowHudOpacityPercent / 100.0f;
        // Yarı saydam arka plan paneli KALDIRILDI (Kullanıcı isteği)
        // --- Yan Yana (Side-by-side) Düzen ---
        context.getMatrices().pushMatrix();
        context.getMatrices().translate((float) x, (float) y);
        context.getMatrices().scale(baseScale, baseScale);

        boolean hasLoaded = !loadedArrow.isEmpty();

        int currentX = 0;

        // Kalan ok ikonu
        context.getMatrices().pushMatrix();
        float cx = currentX + 8;
        float cy = 8;
        context.getMatrices().translate(cx, cy);
        context.getMatrices().scale(bounceScale, bounceScale);
        context.getMatrices().translate(-cx, -cy);

        context.drawItem(arrowStack, currentX, 0);
        context.getMatrices().popMatrix();

        currentX += 18;

        // Sayı rengi
        int alpha = (int) (opacity * 255.0f) << 24;
        int textColor;
        if (count >= 15)
            textColor = alpha | 0xFFFFFF;
        else if (count >= 10)
            textColor = alpha | 0xFFAA00;
        else if (count >= 5)
            textColor = alpha | 0xFF4400;
        else
            textColor = alpha | 0xDD0000;

        String countText = String.valueOf(count);
        context.drawTextWithShadow(client.textRenderer, countText, currentX, 4, textColor);
        currentX += client.textRenderer.getWidth(countText) + 4;

        // Eğer crossbow'da ok varsa sonra o gösterilir
        if (hasLoaded) {
            context.drawTextWithShadow(client.textRenderer, "§7/", currentX, 4, 0xFFFFFF);
            currentX += 10;
            context.drawItem(loadedArrow, currentX, 0);
        }

        context.getMatrices().popMatrix();
    }

    private ItemStack getRelevantArrow(ClientPlayerEntity player, ItemStack mainHand, ItemStack offHand,
            boolean hasCrossbow) {
        // Vanilla Crossbow priority: Offhand first
        if (player.getOffHandStack().isIn(ItemTags.ARROWS)) {
            return player.getOffHandStack().copy();
        }
        // Then first arrow found in inventory from slot 0
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isIn(ItemTags.ARROWS)) {
                return stack.copy();
            }
        }
        return ItemStack.EMPTY;
    }

    private int countArrowsOfType(ClientPlayerEntity player, ItemStack arrowType) {
        int count = 0;
        ItemStack offHand = player.getOffHandStack();
        if (ItemStack.areItemsAndComponentsEqual(offHand, arrowType))
            count += offHand.getCount();
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (ItemStack.areItemsAndComponentsEqual(stack, arrowType))
                count += stack.getCount();
        }
        return count;
    }
}
