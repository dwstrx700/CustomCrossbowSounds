package net.customcrossbowsounds.client.hud;

import me.shedaniel.autoconfig.AutoConfig;
import net.customcrossbowsounds.config.CustomCrossbowSoundsConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.RotationAxis;

public class ChargeIndicatorRenderer implements HudRenderCallback {

    private static final String[] WALKSY_IDS = {
            "crosshairaddons", "walksy_crosshair", "walksy_crosshair_addons", "crosshair_addons", "crosshair"
    };

    private boolean isWalksyLoaded() {
        for (String id : WALKSY_IDS) {
            if (FabricLoader.getInstance().isModLoaded(id))
                return true;
        }
        return false;
    }

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        if (!isWalksyLoaded())
            return;

        CustomCrossbowSoundsConfig config = AutoConfig.getConfigHolder(CustomCrossbowSoundsConfig.class).getConfig();
        if (!config.enabled || !config.chargeIndicatorEnabled)
            return;

        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || !player.isUsingItem())
            return;

        ItemStack stack = player.getActiveItem();
        if (!(stack.getItem() instanceof CrossbowItem))
            return;

        int useTime = player.getItemUseTime();
        // 1.21 pull time helper (stack, livingEntity)
        int maxTime = CrossbowItem.getPullTime(stack, player);
        float progress = Math.min((float) useTime / maxTime, 1.0f);

        if (progress <= 0.05f)
            return;

        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();

        // Coordinates
        int centerX = (screenWidth / 2) + config.chargeIndicatorX;
        int centerY = (screenHeight / 2) + config.chargeIndicatorY;

        if (config.chargeIndicatorY == 0
                && config.chargeIndicatorType == CustomCrossbowSoundsConfig.ChargeIndicatorType.PIZZA) {
            centerY += 14; // Default position slightly below crosshair for pizza
        }

        context.getMatrices().pushMatrix();
        context.getMatrices().translate((float) centerX, (float) centerY);
        context.getMatrices().scale(config.chargeIndicatorScale, config.chargeIndicatorScale);

        // shadow
        drawArcWithFill(context, 6, 1.0f, config.chargeIndicatorType, 0x44000000);

        // foreground
        int color = 0xFFFFFFFF; // White
        if (progress >= 1.0f)
            color = 0xFF00FF00; // Green when fully charged
        drawArcWithFill(context, 6, progress, config.chargeIndicatorType, color);

        context.getMatrices().popMatrix();
    }

    private void drawArcWithFill(DrawContext context, float radius, float progress,
            CustomCrossbowSoundsConfig.ChargeIndicatorType type, int argb) {

        int gridR = 4; // 9x9 tam kare alan. (-4 to 4) = 9 blok.
        float outerRadiusSq = 4.5f * 4.5f;
        float innerRadiusSq = 2.0f * 2.0f; // Simit (Donut) kalınlığı için iç boşluk

        for (int y = -gridR; y <= gridR; y++) {
            for (int x = -gridR; x <= gridR; x++) {
                // Merkezden uzaklığı hesapla (Karenin merkezini x+0.5, y+0.5 olarak kabul
                // ediyoruz)
                float cx = x + 0.5f;
                float cy = y + 0.5f;
                float distSq = cx * cx + cy * cy;

                // Dış yuvarlak içine giriyor mu?
                if (distSq <= outerRadiusSq) {

                    // Simit ise, iç kısmını boş bırak
                    if (type == CustomCrossbowSoundsConfig.ChargeIndicatorType.DONUT && distSq < innerRadiusSq) {
                        continue;
                    }

                    // Açıyı hesapla: Üst merkez = 0, Saat yönünde 360
                    double angle = Math.toDegrees(Math.atan2(cy, cx)) + 90.0;
                    if (angle < 0)
                        angle += 360.0;

                    if (angle / 360.0 <= progress) {
                        context.fill(x, y, x + 1, y + 1, argb);
                    }
                }
            }
        }
    }
}
