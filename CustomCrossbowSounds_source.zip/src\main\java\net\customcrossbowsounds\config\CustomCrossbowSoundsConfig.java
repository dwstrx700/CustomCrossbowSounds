package net.customcrossbowsounds.config;

import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.Config;
import me.shedaniel.autoconfig.annotation.ConfigEntry;

@Config(name = "customcrossbowsounds")
public class CustomCrossbowSoundsConfig implements ConfigData {

    public boolean enabled = true;

    @ConfigEntry.Category("sound")
    public SoundType hitSoundType = SoundType.BELL;

    @ConfigEntry.Category("sound")
    @ConfigEntry.Gui.Tooltip
    public String customSoundName = "custom_hit.ogg";

    @ConfigEntry.Category("sound")
    @ConfigEntry.BoundedDiscrete(min = 0, max = 500)
    public int soundVolumePercent = 100;

    @ConfigEntry.Category("visual")
    public boolean showParticles = true;

    @ConfigEntry.Category("visual")
    @ConfigEntry.ColorPicker
    public int particleColor = 0xFF0000;

    // Arrow HUD Settings
    @ConfigEntry.Category("hud")
    public boolean arrowHudEnabled = true;

    @ConfigEntry.Category("hud")
    public int arrowHudX = 10;

    @ConfigEntry.Category("hud")
    public int arrowHudY = 10;

    @ConfigEntry.Category("hud")
    public float arrowHudScale = 1.0f;

    @ConfigEntry.Category("hud")
    @ConfigEntry.BoundedDiscrete(min = 0, max = 100)
    public int arrowHudOpacityPercent = 100;

    // Charge Indicator Settings
    @ConfigEntry.Category("hud")
    public boolean chargeIndicatorEnabled = true;

    @ConfigEntry.Category("hud")
    public ChargeIndicatorType chargeIndicatorType = ChargeIndicatorType.DONUT;

    @ConfigEntry.Category("hud")
    public int chargeIndicatorX = 0; // Default center X offset

    @ConfigEntry.Category("hud")
    public int chargeIndicatorY = 0; // Default center Y offset

    @ConfigEntry.Category("hud")
    public float chargeIndicatorScale = 1.0f;

    public enum ChargeIndicatorType {
        PIZZA, DONUT
    }

    public enum SoundType {
        BELL,
        AMETHYST,
        FIREWORK,
        ANVIL,
        LIGHTNING,
        GOAT_HORN,
        DRAGON,
        TOTEM,
        CUSTOM
    }
}
