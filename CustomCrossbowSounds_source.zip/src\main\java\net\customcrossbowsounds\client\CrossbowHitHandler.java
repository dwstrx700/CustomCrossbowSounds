package net.customcrossbowsounds.client;

import net.customcrossbowsounds.config.CustomCrossbowSoundsConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

@Environment(EnvType.CLIENT)
public class CrossbowHitHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger("customcrossbowsounds");
    public static final Identifier CUSTOM_SOUND_ID = Identifier.of("customcrossbowsounds", "custom_hit");
    public static SoundEvent CUSTOM_SOUND_EVENT = SoundEvent.of(CUSTOM_SOUND_ID);

    /** Folder where users place their .ogg files */
    public static Path getCustomSoundsFolder() {
        return FabricLoader.getInstance().getGameDir().resolve("customcrossbowsounds").resolve("sounds");
    }

    public static void onPlayerHit() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null)
            return;

        CustomCrossbowSoundsConfig config = me.shedaniel.autoconfig.AutoConfig
                .getConfigHolder(CustomCrossbowSoundsConfig.class).getConfig();

        if (!config.enabled)
            return;

        // Play Sound
        SoundEvent sound = getTargetSoundOrNull(config);
        if (sound != null) {
            float volume = config.soundVolumePercent / 100.0f;
            client.getSoundManager().play(
                    new PositionedSoundInstance(
                            sound.id(),
                            SoundCategory.PLAYERS,
                            volume,
                            1.0f,
                            Random.create(),
                            false,
                            0,
                            net.minecraft.client.sound.SoundInstance.AttenuationType.NONE,
                            0.0, 0.0, 0.0,
                            true));
        }

        // Spawn Particles
        if (config.showParticles) {
            Vec3d pos = client.player.getCameraPosVec(1.0f)
                    .add(client.player.getRotationVec(1.0f).multiply(2.0));

            Random random = client.world.random;
            ParticleManager pm = client.particleManager;
            for (int i = 0; i < 15; i++) {
                double offsetX = (random.nextDouble() - 0.5) * 0.5;
                double offsetY = (random.nextDouble() - 0.5) * 0.5;
                double offsetZ = (random.nextDouble() - 0.5) * 0.5;
                pm.addParticle(
                        ParticleTypes.FIREWORK,
                        pos.x + offsetX, pos.y + offsetY, pos.z + offsetZ,
                        offsetX * 0.1, offsetY * 0.1, offsetZ * 0.1);
            }
        }
    }

    private static SoundEvent getTargetSoundOrNull(CustomCrossbowSoundsConfig config) {
        return switch (config.hitSoundType) {
            case BELL -> SoundEvents.BLOCK_BELL_USE;
            case AMETHYST -> SoundEvents.BLOCK_AMETHYST_BLOCK_HIT;
            case FIREWORK -> SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST;
            case ANVIL -> SoundEvents.BLOCK_ANVIL_BREAK;
            case LIGHTNING -> SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER;
            case GOAT_HORN -> SoundEvents.ENTITY_GOAT_HORN_BREAK;
            case DRAGON -> SoundEvents.ENTITY_ENDER_DRAGON_GROWL;
            case TOTEM -> SoundEvents.ITEM_TOTEM_USE;
            case CUSTOM -> loadCustomSound(config.customSoundName);
        };
    }

    /**
     * Loads a .ogg file from .minecraft/customcrossbowsounds/sounds/<name>
     * and copies it into the game resource pack cache so the SoundManager can play
     * it.
     * Falls back to BELL if file not found.
     */
    private static SoundEvent loadCustomSound(String fileName) {
        try {
            Path soundsDir = getCustomSoundsFolder();
            if (!Files.exists(soundsDir)) {
                Files.createDirectories(soundsDir);
                LOGGER.info("[CustomCrossbowSounds] Created sounds folder: {}", soundsDir);
            }

            Path targetFile = soundsDir.resolve(fileName);
            if (!Files.exists(targetFile)) {
                LOGGER.warn("[CustomCrossbowSounds] Custom sound file not found: {}", targetFile);
                LOGGER.warn("[CustomCrossbowSounds] Place your .ogg file at: {}", targetFile);
                return SoundEvents.BLOCK_BELL_USE; // fallback
            }

            // Copy the .ogg into the game's resource directory so the SoundManager picks it
            // up
            Path resourceDir = FabricLoader.getInstance().getGameDir()
                    .resolve("resourcepacks")
                    .resolve("CustomCrossbowSoundsAuto")
                    .resolve("assets")
                    .resolve("customcrossbowsounds")
                    .resolve("sounds");
            Files.createDirectories(resourceDir);
            Files.copy(targetFile, resourceDir.resolve("custom_hit.ogg"), StandardCopyOption.REPLACE_EXISTING);

            return CUSTOM_SOUND_EVENT;
        } catch (Exception e) {
            LOGGER.error("[CustomCrossbowSounds] Failed to load custom sound: {}", e.getMessage());
            return SoundEvents.BLOCK_BELL_USE;
        }
    }
}
