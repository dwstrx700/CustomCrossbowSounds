package net.customcrossbowsounds;

import java.lang.reflect.Method;
import java.lang.reflect.Constructor;
import java.util.Arrays;

public class ApiProbe {
    public static void main(String[] args) throws Exception {
        // Check MatrixStack / Matrix4fStack translate and scale
        Class<?> msClass = Class.forName("net.minecraft.client.util.math.MatrixStack");
        System.out.println("=== MatrixStack methods ===");
        for (Method m : msClass.getDeclaredMethods()) {
            if (m.getName().equals("translate") || m.getName().equals("scale") ||
                m.getName().equals("push") || m.getName().equals("pop") ||
                m.getName().equals("pushMatrix") || m.getName().equals("popMatrix")) {
                System.out.println(m.getName() + " -> " + Arrays.toString(m.getParameterTypes()) + " ret:" + m.getReturnType());
            }
        }

        // Check DrawContext getMatrices
        Class<?> dcClass = Class.forName("net.minecraft.client.gui.DrawContext");
        System.out.println("\n=== DrawContext.getMatrices() return type ===");
        for (Method m : dcClass.getDeclaredMethods()) {
            if (m.getName().equals("getMatrices")) {
                System.out.println("getMatrices -> returns: " + m.getReturnType().getName());
            }
        }

        // Check Element/ParentElement mouseClicked and mouseReleased
        System.out.println("\n=== Element mouse methods ===");
        try {
            Class<?> elemClass = Class.forName("net.minecraft.client.gui.Element");
            for (Method m : elemClass.getDeclaredMethods()) {
                if (m.getName().contains("mouse")) {
                    System.out.println("Element." + m.getName() + " -> " + Arrays.toString(m.getParameterTypes()));
                }
            }
        } catch (Exception e) {
            System.out.println("Element not found: " + e.getMessage());
        }
        
        try {
            Class<?> parentElemClass = Class.forName("net.minecraft.client.gui.ParentElement");
            for (Method m : parentElemClass.getDeclaredMethods()) {
                if (m.getName().contains("mouse")) {
                    System.out.println("ParentElement." + m.getName() + " -> " + Arrays.toString(m.getParameterTypes()));
                }
            }
        } catch (Exception e) {
            System.out.println("ParentElement not found: " + e.getMessage());
        }

        try {
            Class<?> screenClass = Class.forName("net.minecraft.client.gui.screen.Screen");
            for (Method m : screenClass.getDeclaredMethods()) {
                if (m.getName().contains("mouse")) {
                    System.out.println("Screen." + m.getName() + " -> " + Arrays.toString(m.getParameterTypes()));
                }
            }
        } catch (Exception e) {
            System.out.println("Screen not found: " + e.getMessage());
        }

        // Check KeyBinding constructors
        System.out.println("\n=== KeyBinding constructors ===");
        try {
            Class<?> kbClass = Class.forName("net.minecraft.client.option.KeyBinding");
            for (Constructor<?> c : kbClass.getConstructors()) {
                System.out.println("KeyBinding(" + Arrays.toString(c.getParameterTypes()) + ")");
            }
            // Also check for MISC_CATEGORY field
            try {
                var field = kbClass.getField("MISC_CATEGORY");
                System.out.println("MISC_CATEGORY field type: " + field.getType());
            } catch (NoSuchFieldException e) {
                System.out.println("No MISC_CATEGORY field found");
            }
            // List all public static fields
            for (var f : kbClass.getFields()) {
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                    System.out.println("  static field: " + f.getName() + " type: " + f.getType());
                }
            }
        } catch (Exception e) {
            System.out.println("KeyBinding not found: " + e.getMessage());
        }

        // Check PositionedSoundInstance.master
        System.out.println("\n=== PositionedSoundInstance methods ===");
        try {
            Class<?> psiClass = Class.forName("net.minecraft.client.sound.PositionedSoundInstance");
            for (Method m : psiClass.getDeclaredMethods()) {
                if (m.getName().equals("master")) {
                    System.out.println("master -> " + Arrays.toString(m.getParameterTypes()));
                }
            }
        } catch (Exception e) {
            System.out.println("PositionedSoundInstance not found: " + e.getMessage());
        }

        // Check World.addParticle
        System.out.println("\n=== World.addParticle ===");
        try {
            Class<?> worldClass = Class.forName("net.minecraft.world.World");
            for (Method m : worldClass.getDeclaredMethods()) {
                if (m.getName().equals("addParticle")) {
                    System.out.println("addParticle -> " + Arrays.toString(m.getParameterTypes()));
                }
            }
        } catch (Exception e) {
            System.out.println("World not found: " + e.getMessage());
        }
    }
}
