package net.customcrossbowsounds.mixin;

import net.minecraft.client.sound.SoundLoader;
import net.minecraft.client.sound.AudioStream;
import net.minecraft.client.sound.OggAudioStream;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.CompletableFuture;

@Mixin(SoundLoader.class)
public class SoundLoaderMixin {
    @Inject(method = "loadStreamed", at = @At("HEAD"), cancellable = true)
    private void onLoadStreamed(Identifier id, boolean repeat, CallbackInfoReturnable<CompletableFuture<AudioStream>> cir) {
        if (id.getNamespace().equals("customcrossbowsounds") && id.getPath().equals("sounds/custom_hit.ogg")) {
            File f = new File("config/customcrossbowsounds/custom_hit.ogg");
            if (f.exists()) {
                cir.setReturnValue(CompletableFuture.supplyAsync(() -> {
                    try {
                        return new OggAudioStream(new FileInputStream(f));
                    } catch (Exception e) {
                        e.printStackTrace();
                        return null;
                    }
                }));
            }
        }
    }
}
