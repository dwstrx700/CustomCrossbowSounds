package net.customcrossbowsounds.mixin;

import net.customcrossbowsounds.client.CrossbowHitHandler;
import net.customcrossbowsounds.config.CustomCrossbowSoundsConfig;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.GameStateChangeS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {

    @Inject(method = "onGameStateChange", at = @At("HEAD"), cancellable = true)
    private void onGameStateChangeHook(GameStateChangeS2CPacket packet, CallbackInfo ci) {
        if (packet.getReason() == GameStateChangeS2CPacket.PROJECTILE_HIT_PLAYER) {
            CustomCrossbowSoundsConfig config = me.shedaniel.autoconfig.AutoConfig.getConfigHolder(CustomCrossbowSoundsConfig.class).getConfig();
            
            // If mod is enabled, we trigger our feedback
            if (config != null && config.enabled) {
                CrossbowHitHandler.onPlayerHit();
                
                // Cancel to prevent the default vanilla "ding" sound
                ci.cancel();
            }
        }
    }
}
