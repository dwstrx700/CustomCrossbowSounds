package net.customcrossbowsounds.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;
import net.customcrossbowsounds.config.CustomCrossbowSoundsConfig;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import net.customcrossbowsounds.client.hud.ArrowHudRenderer;
import net.customcrossbowsounds.client.hud.ArrowHudEditScreen;
import net.customcrossbowsounds.client.hud.ChargeIndicatorRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

@Environment(EnvType.CLIENT)
public class CustomCrossbowSoundsClient implements ClientModInitializer {
    public static final String MOD_ID = "customcrossbowsounds";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static KeyBinding editHudKeyBinding;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Starting Custom Crossbow Sounds Client!");

        AutoConfig.register(CustomCrossbowSoundsConfig.class, GsonConfigSerializer::new);

        // Register the HUD
        HudRenderCallback.EVENT.register(new ArrowHudRenderer());
        HudRenderCallback.EVENT.register(new ChargeIndicatorRenderer());

        // Register KeyBinding for the Edit Screen
        editHudKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.customcrossbowsounds.edithud",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                KeyBinding.Category.MISC)); // Handle Key Presses
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (editHudKeyBinding.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new ArrowHudEditScreen(client.currentScreen));
                }
            }
        });
    }
}
