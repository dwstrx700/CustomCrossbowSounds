package net.customcrossbowsounds.client;

import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourcePack;
import net.minecraft.resource.InputSupplier;
import net.minecraft.util.Identifier;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.File;

public class ResourceTest {
    public void test() {
        File f = new File("test.ogg");
        InputSupplier<InputStream> supplier = () -> new FileInputStream(f);
        // We will see what constructors exist for Resource
        Resource r = new Resource(null, supplier); // Test if this compiles
    }
}
